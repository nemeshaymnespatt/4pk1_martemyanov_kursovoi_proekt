﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;
using System.Drawing;



namespace WpfApp5
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        LombardDbContext dbContext;
        Box_office Box = new Box_office();
        public Window2(LombardDbContext dbContext)
        {
            InitializeComponent();
            this.dbContext = dbContext;
            GetBoxes();

            DGAdd.DataContext = Box;
        }



        private void GetBoxes()
        {
            DGLombard.ItemsSource = dbContext.Boxes.ToList();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            dbContext.Boxes.Add(Box);
            dbContext.SaveChanges();
            GetBoxes();
            Box = new Box_office();
            DGAdd.DataContext = Box;
        }
        Box_office selectedBox = new Box_office();
        private void UpdateClikForEdit(object s, RoutedEventArgs e)
        {
            selectedBox = (s as FrameworkElement).DataContext as Box_office;
            DGUpdate.DataContext = selectedBox;
            string ididi = selectedBox.image.ToString();
            Image.Source = new BitmapImage(new Uri(ididi));
        }

        private void UpdateClick(object sender, RoutedEventArgs e)
        {
            dbContext.Update(selectedBox);
            dbContext.SaveChanges();
            GetBoxes();
        }
        private void DeleteClick(object s, RoutedEventArgs e)
        {
            var boxForDelete = (s as FrameworkElement).DataContext as Box_office;
            dbContext.Remove(boxForDelete);
            dbContext.SaveChanges();
            GetBoxes();
        }

        private void PictureIn()
        {
            System.Windows.Forms.OpenFileDialog OPF = new System.Windows.Forms.OpenFileDialog();
            OPF.Filter = "Файлы PNG|*.PNG|Файлы cs|Form1.cs"; //PNG, JPEG, GIF, RAW, TIFF, BMP, PSD
            OPF.Multiselect = true;
            if (OPF.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                foreach (string file in OPF.FileNames)
                {

                    Image.Source = new BitmapImage(new Uri(OPF.FileName));
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PictureIn();
            tbbb1.Text = Image.Source.ToString().Substring(8);
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            PictureIn();
            tbbb.Text = Image.Source.ToString().Substring(8);
        }
    }
}